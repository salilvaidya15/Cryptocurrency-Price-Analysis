setwd("/Users/rohanp/test")
library(shiny)
runApp(host = "0.0.0.0", port = 5050)